import React from 'react';
import {C} from '../theme';
import {Pos} from './Pos';
const N = 21, size = 340, c = size / N, INK = '#12173a';
const finder = (i: number, j: number) => (i < 7 && j < 7) || (i < 7 && j >= N - 7) || (i >= N - 7 && j < 7);
const F = (fx: number, fy: number) => (
  <g transform={`translate(${fx * c},${fy * c})`}>
    <rect width={7 * c} height={7 * c} fill={INK} /><rect x={c} y={c} width={5 * c} height={5 * c} fill="#fff" />
    <rect x={2 * c} y={2 * c} width={3 * c} height={3 * c} fill={INK} />
  </g>
);
// Original (fake) QR pattern. scan 0..1 = scan line ki position, -1 = line nahi
export const QRCode: React.FC<{x: number; y: number; s?: number; o?: number; scan?: number}> = ({x, y, s = 1, o = 1, scan = -1}) => {
  const cells: React.ReactNode[] = [];
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
    if (!finder(i, j) && (i * 7 + j * 13 + i * j) % 3 === 0) cells.push(<rect key={`${i}-${j}`} x={j * c} y={i * c} width={c} height={c} fill={INK} />);
  }
  return (
    <Pos x={x} y={y} s={s} o={o}>
      <div style={{background: '#fff', padding: 24, borderRadius: 24, position: 'relative'}}>
        <svg width={size} height={size}>{cells}{F(0, 0)}{F(N - 7, 0)}{F(0, N - 7)}</svg>
        {scan >= 0 && <div style={{position: 'absolute', left: 14, right: 14, top: 24 + scan * size, height: 8, borderRadius: 4,
          background: C.note2, boxShadow: `0 0 24px 6px ${C.note}`}} />}
      </div>
    </Pos>
  );
};
