import React from 'react';
import {C, FONT} from '../theme';
import {Pos} from './Pos';
export const Bank: React.FC<{x: number; y: number; s?: number; o?: number; label?: string}> = ({x, y, s = 1, o = 1, label}) => (
  <Pos x={x} y={y} s={s} o={o}>
    <div style={{textAlign: 'center', fontFamily: FONT}}>
      <svg width={200} height={170} viewBox="0 0 200 170">
        <polygon points="100,8 192,56 8,56" fill={C.note2} />
        {[28, 87, 146].map((x0) => <rect key={x0} x={x0} y={66} width={26} height={62} rx={5} fill={C.note} />)}
        <rect x={10} y={136} width={180} height={22} rx={7} fill={C.note2} />
      </svg>
      {label && <div style={{fontSize: 34, fontWeight: 800, marginTop: 8, whiteSpace: 'nowrap'}}>{label}</div>}
    </div>
  </Pos>
);
