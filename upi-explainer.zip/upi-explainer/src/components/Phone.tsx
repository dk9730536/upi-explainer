import React from 'react';
import {C, FONT} from '../theme';
import {Pos} from './Pos';
export const Phone: React.FC<{x: number; y: number; s?: number; o?: number; children?: React.ReactNode}> =
  ({x, y, s = 1, o = 1, children}) => (
    <Pos x={x} y={y} s={s} o={o}>
      <div style={{width: 280, height: 520, borderRadius: 44, border: `8px solid ${C.line}`, background: C.bg2,
        boxShadow: '0 20px 60px rgba(0,0,0,.45)', display: 'flex', flexDirection: 'column', alignItems: 'center',
        justifyContent: 'center', position: 'relative', overflow: 'hidden', fontFamily: FONT}}>
        <div style={{position: 'absolute', top: 14, width: 80, height: 10, borderRadius: 6, background: C.line}} />
        {children}
      </div>
    </Pos>
  );
