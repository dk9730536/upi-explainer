import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT} from '../theme';
import {Pos} from './Pos';
const nodes = [[50, 110], [120, 45], [205, 55], [275, 115], [195, 160], [110, 155]];
const edges = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0], [1, 4], [2, 5]];
const cloud = [{c: [105, 115, 52]}, {c: [165, 85, 62]}, {c: [228, 118, 48]}];
// routing: 0 = cloud (server jaisa), 1 = routing/network graphic
export const Network: React.FC<{x: number; y: number; s?: number; o?: number; inner?: string; label?: string; routing?: number}> =
  ({x, y, s = 1, o = 1, inner = 'UPI', label, routing = 0}) => {
    const f = useCurrentFrame();
    const pulse = 0.6 + 0.4 * Math.sin(f / 9);
    return (
      <Pos x={x} y={y} s={s} o={o}>
        <div style={{textAlign: 'center', fontFamily: FONT}}>
          <svg width={320} height={200} viewBox="0 0 320 200">
            <g opacity={1 - routing}>
              <g fill={C.note} stroke={C.note} strokeWidth={10}>
                {cloud.map((k, i) => <circle key={i} cx={k.c[0]} cy={k.c[1]} r={k.c[2]} />)}
                <rect x={105} y={118} width={123} height={49} />
              </g>
              <g fill={C.card}>
                {cloud.map((k, i) => <circle key={i} cx={k.c[0]} cy={k.c[1]} r={k.c[2]} />)}
                <rect x={105} y={118} width={123} height={49} />
              </g>
              <text x={165} y={132} textAnchor="middle" fontSize={54} fontWeight={800} fill={C.fg}>{inner}</text>
            </g>
            <g opacity={routing}>
              {edges.map(([a, b], i) => <line key={i} x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]}
                stroke={C.note} strokeWidth={4} opacity={0.7} />)}
              {nodes.map((n, i) => <circle key={i} cx={n[0]} cy={n[1]} r={i % 2 ? 13 : 13 * (0.8 + 0.3 * pulse)} fill={C.note} />)}
            </g>
          </svg>
          {label && <div style={{fontSize: 34, fontWeight: 800, marginTop: 6, whiteSpace: 'nowrap'}}>{label}</div>}
        </div>
      </Pos>
    );
  };
