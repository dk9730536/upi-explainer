import React from 'react';
import {C} from '../theme';
import {Pos} from './Pos';
// open: 0 = band, 1 = khula
export const Lock: React.FC<{x: number; y: number; s?: number; o?: number; open?: number; color?: string}> =
  ({x, y, s = 1, o = 1, open = 0, color = C.note}) => (
    <Pos x={x} y={y} s={s} o={o}>
      <svg width={120} height={150} viewBox="0 0 120 150">
        <path d={`M32 66 V42 a28 28 0 0 1 56 0 V${66 - 22 * open}`} fill="none" stroke={color} strokeWidth={12} strokeLinecap="round" />
        <rect x={18} y={64} width={84} height={72} rx={14} fill={color} />
        <circle cx={60} cy={94} r={9} fill={C.bg} /><rect x={56} y={100} width={8} height={18} rx={3} fill={C.bg} />
      </svg>
    </Pos>
  );
