import React from 'react';
import {AbsoluteFill} from 'remotion';
import {fade, useT} from '../anim';
// Har scene ka wrapper: t = absolute seconds deta hai + scene ke start/end pe fade
export const Scene: React.FC<{a: number; b: number; children: (t: number) => React.ReactNode}> = ({a, b, children}) => {
  const t = useT(a);
  return <AbsoluteFill style={{opacity: fade(t, a, b)}}>{children(t)}</AbsoluteFill>;
};
