import React from 'react';
import {C} from '../theme';
import {Pos} from './Pos';
export const Warning: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <Pos x={x} y={y} s={s} o={o}>
    <svg width={200} height={180} viewBox="0 0 200 180">
      <polygon points="100,16 186,164 14,164" fill={C.warn} stroke={C.warn} strokeWidth={14} strokeLinejoin="round" />
      <rect x={91} y={66} width={18} height={52} rx={9} fill={C.bg} /><circle cx={100} cy={140} r={10} fill={C.bg} />
    </svg>
  </Pos>
);
// "NO" sign (lal circle + slash)
export const NoSign: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 1}) => (
  <Pos x={x} y={y} s={s} o={o}>
    <svg width={170} height={170} viewBox="0 0 170 170">
      <circle cx={85} cy={85} r={70} fill="rgba(11,16,32,.75)" stroke={C.bad} strokeWidth={14} />
      <line x1={36} y1={36} x2={134} y2={134} stroke={C.bad} strokeWidth={14} strokeLinecap="round" />
    </svg>
  </Pos>
);
