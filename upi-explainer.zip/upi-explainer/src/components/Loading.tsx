import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../theme';
import {Pos} from './Pos';
export const Loading: React.FC<{x: number; y: number; size?: number; o?: number; color?: string}> = ({x, y, size = 80, o = 1, color = C.note}) => {
  const f = useCurrentFrame();
  return (
    <Pos x={x} y={y} o={o}>
      <div style={{width: size, height: size, borderRadius: '50%', border: `${size / 8}px solid ${C.line}`,
        borderTopColor: color, transform: `rotate(${f * 10}deg)`}} />
    </Pos>
  );
};
