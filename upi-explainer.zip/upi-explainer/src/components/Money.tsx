import React from 'react';
import {C, FONT} from '../theme';
import {Pos} from './Pos';
export const Money: React.FC<{x: number; y: number; s?: number; o?: number; r?: number; text?: string}> =
  ({x, y, s = 1, o = 1, r = 0, text = '₹100'}) => (
    <Pos x={x} y={y} s={s} o={o} r={r}>
      <div style={{width: 240, height: 120, borderRadius: 16, background: `linear-gradient(135deg,${C.note},${C.note2})`,
        border: '4px dashed rgba(255,255,255,.55)', display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 64, fontWeight: 800, color: '#1a1240', boxShadow: `0 0 40px ${C.note2}`, fontFamily: FONT}}>{text}</div>
    </Pos>
  );
