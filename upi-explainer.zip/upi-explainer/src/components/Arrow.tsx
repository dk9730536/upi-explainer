import React from 'react';
import {C} from '../theme';
// (x1,y1) se (x2,y2) tak arrow. prog 0..1 = kitna draw hua
export const Arrow: React.FC<{x1: number; y1: number; x2: number; y2: number; prog?: number; color?: string; width?: number; o?: number; dashed?: boolean}> =
  ({x1, y1, x2, y2, prog = 1, color = C.note, width = 10, o = 1, dashed = false}) => {
    const ex = x1 + (x2 - x1) * prog, ey = y1 + (y2 - y1) * prog;
    const ang = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
    return (
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0, opacity: o, pointerEvents: 'none'}}>
        <line x1={x1} y1={y1} x2={ex} y2={ey} stroke={color} strokeWidth={width} strokeLinecap="round"
          strokeDasharray={dashed ? '4 22' : undefined} />
        {prog > 0.03 && <polygon points="-36,-22 0,0 -36,22" fill={color} transform={`translate(${ex},${ey}) rotate(${ang})`} />}
      </svg>
    );
  };
