import React from 'react';
// Har cheez ko (x,y) center pe rakhne wala wrapper. s=scale, o=opacity, r=rotation
export const Pos: React.FC<{x: number; y: number; s?: number; o?: number; r?: number; children: React.ReactNode}> =
  ({x, y, s = 1, o = 1, r = 0, children}) => (
    <div style={{position: 'absolute', left: x, top: y, opacity: o,
      transform: `translate(-50%,-50%) scale(${s}) rotate(${r}deg)`}}>{children}</div>
  );
