import React from 'react';
import {C} from '../theme';
import {Pos} from './Pos';
// prog 0..1 = tick draw hota hua
export const Tick: React.FC<{x: number; y: number; s?: number; o?: number; prog?: number; color?: string}> =
  ({x, y, s = 1, o = 1, prog = 1, color = C.ok}) => (
    <Pos x={x} y={y} s={s} o={o}>
      <svg width={160} height={160} viewBox="0 0 160 160">
        <circle cx={80} cy={80} r={70} fill="none" stroke={color} strokeWidth={10} strokeDasharray={440} strokeDashoffset={440 * (1 - Math.min(1, prog * 1.6))} />
        <path d="M46 84 L70 108 L116 56" fill="none" stroke={color} strokeWidth={12} strokeLinecap="round" strokeLinejoin="round"
          strokeDasharray={120} strokeDashoffset={120 * (1 - Math.max(0, (prog - 0.4) / 0.6))} />
      </svg>
    </Pos>
  );
