import React from 'react';
import {C, FONT} from '../theme';
import {Pos} from './Pos';
// Title: rise 0..1 = neeche se upar slide hota hua
export const Title: React.FC<{text: string; y: number; x?: number; size?: number; color?: string; o?: number; rise?: number; weight?: number}> =
  ({text, y, x = 960, size = 64, color = C.fg, o = 1, rise = 1, weight = 800}) => (
    <div style={{position: 'absolute', left: x, top: y, opacity: o, fontFamily: FONT, fontSize: size, fontWeight: weight, color,
      whiteSpace: 'nowrap', lineHeight: 1.25, transform: `translate(-50%,-50%) translateY(${(1 - rise) * 36}px)`}}>{text}</div>
  );
// Caption: neeche wala bada statement box
export const Caption: React.FC<{text: string; y?: number; o?: number}> = ({text, y = 900, o = 1}) => (
  <div style={{position: 'absolute', left: 960, top: y, opacity: o, fontFamily: FONT, fontSize: 56, fontWeight: 800, whiteSpace: 'nowrap',
    background: C.card, border: `3px solid ${C.line}`, borderRadius: 28, padding: '22px 48px', boxShadow: '0 12px 40px rgba(0,0,0,.4)',
    transform: `translate(-50%,-50%) translateY(${(1 - o) * 30}px)`}}>{text}</div>
);
export const Pill: React.FC<{text: string; x: number; y: number; w?: number; h?: number; o?: number; color?: string; fill?: string; size?: number}> =
  ({text, x, y, w = 460, h = 90, o = 1, color = C.fg, fill = C.card, size = 40}) => (
    <Pos x={x} y={y} o={o}>
      <div style={{width: w, height: h, borderRadius: h / 2, background: fill, border: `3px solid ${C.line}`, color, fontFamily: FONT,
        fontSize: size, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', whiteSpace: 'nowrap',
        boxShadow: '0 8px 28px rgba(0,0,0,.35)'}}>{text}</div>
    </Pos>
  );
