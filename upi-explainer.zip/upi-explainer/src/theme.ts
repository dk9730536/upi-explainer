import {loadFont} from '@remotion/google-fonts/NotoSansDevanagari';
const {fontFamily} = loadFont('normal', {weights: ['600', '800'], subsets: ['devanagari', 'latin']});
export const FONT = `${fontFamily}, "Nirmala UI", "Noto Sans", sans-serif`;
export const C = {
  bg: '#0b1020', bg2: '#151c3a', card: '#1c2450', line: '#3a4275', fg: '#f3f1ff', dim: '#9aa1d6',
  note: '#b9a7ff', note2: '#7f6bdc', ok: '#4ee0a1', bad: '#ff6b5e', warn: '#ffc857', mint: '#5ce0b8',
};
