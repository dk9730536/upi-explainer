import {interpolate, Easing, useCurrentFrame, useVideoConfig} from 'remotion';
const K = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const lin = (t: number, a: number, b: number) => interpolate(t, [a, b], [0, 1], K);
// p = smooth 0..1 progress between second a and b
export const p = (t: number, a: number, b: number) =>
  interpolate(t, [a, b], [0, 1], {...K, easing: Easing.bezier(0.4, 0, 0.2, 1)});
export const lerp = (a: number, b: number, x: number) => a + (b - a) * x;
export const cl = (x: number) => Math.min(1, Math.max(0, x));
// win = fade in at a, fade out ending at b
export const win = (t: number, a: number, b: number, f = 0.4) => Math.min(lin(t, a, a + f), 1 - lin(t, b - f, b));
export const fade = (t: number, a: number, b: number) => Math.min(lin(t, a, a + 0.5), 1 - lin(t, b - 0.5, b));
export const useT = (start: number) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return f / fps + start;
};
