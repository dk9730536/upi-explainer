export const FPS = 30;
export const TOTAL_SECONDS = 260; // 4:20

// start / end seconds mein. Scene ke andar ke timings bhi "absolute seconds" hain
// (storyboard wale 0:28 = 28, 1:32 = 92) taaki match karna aasaan rahe.
export const SCENES = {
  s1: {start: 0, end: 28},     // Hook
  s2: {start: 28, end: 60},    // Payment shuru
  s3: {start: 60, end: 108},   // Asli system
  s4: {start: 108, end: 162},  // Paisa kahan jata hai
  s5: {start: 162, end: 190},  // UPI PIN
  s6: {start: 190, end: 226},  // Pending
  s7: {start: 226, end: 250},  // Final explanation
  s8: {start: 250, end: 260},  // Channel ending
};
