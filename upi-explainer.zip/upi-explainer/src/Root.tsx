import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, TOTAL_SECONDS} from './timings';

export const Root: React.FC = () => (
  <Composition id="UPIExplainer" component={Video} durationInFrames={TOTAL_SECONDS * FPS}
    fps={FPS} width={1920} height={1080} />
);
