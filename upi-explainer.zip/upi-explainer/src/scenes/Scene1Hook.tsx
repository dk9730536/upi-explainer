import React from 'react';
import {Scene} from '../components/Scene';
import {Phone} from '../components/Phone';
import {Bank} from '../components/Bank';
import {Money} from '../components/Money';
import {Arrow} from '../components/Arrow';
import {Caption, Title} from '../components/Text';
import {Pos} from '../components/Pos';
import {SCENES} from '../timings';
import {C} from '../theme';
import {lerp, lin, p, win} from '../anim';

export const Scene1Hook: React.FC = () => {
  const {start: a, end: b} = SCENES.s1;
  return (
    <Scene a={a} b={b}>{(t) => {
      const pa = p(t, 0, 1), m1 = p(t, 4, 5), k = p(t, 10.8, 11.8), k2 = p(t, 16, 17);
      const ax = lerp(lerp(lerp(960, 560, m1), 360, k), 260, k2);
      const bx = lerp(lerp(1360, 1560, k), 1660, k2);
      const ps = lerp(lerp(1, 0.6, k), 0.5, k2), py = lerp(540, 480, k);
      const dim = 1 - 0.55 * Math.min(p(t, 8, 8.6), 1 - p(t, 10.6, 11.2));
      const noteO = Math.min(p(t, 5, 5.6), lerp(1, 0.35, p(t, 8, 8.6)), 1 - lin(t, 10.8, 11.4));
      const mid = Math.min(p(t, 11, 12), 1 - p(t, 16, 16.8));
      const ch = p(t, 16.4, 17.2), chArrow = p(t, 16.6, 17.4);
      const half = 148 * ps;
      return (<>
        <Phone x={ax} y={py} s={ps * lerp(0.85, 1, pa)} o={pa * dim}>
          <div style={{fontSize: 28, color: C.dim, opacity: p(t, 0.6, 1.6)}}>UPI Payment</div>
          <div style={{fontSize: 76, fontWeight: 800, opacity: p(t, 1, 2.5), transform: `scale(${lerp(0.6, 1, p(t, 1, 2.5))})`}}>₹100</div>
        </Phone>
        <Phone x={bx} y={py} s={ps} o={p(t, 4, 5) * dim}>
          <div style={{fontSize: 28, color: C.dim}}>Receiver</div>
          <div style={{fontSize: 60, fontWeight: 800}}>₹0</div>
        </Phone>
        {/* 4-8: paisa phone se phone ki taraf, 8 pe beech mein ruk jata hai */}
        <Arrow x1={730} y1={650} x2={1200} y2={650} prog={p(t, 5, 8)} o={noteO} />
        <Money x={lerp(560, 960, p(t, 5, 8))} y={540} s={0.7} o={noteO} />
        {/* 8-11: bada question mark */}
        <Title text="?" y={250} size={300} color={C.bad} o={win(t, 8, 11.2)} rise={p(t, 8, 8.8)} />
        <Title text="पैसा जाता कहाँ है?" y={820} size={84} o={win(t, 8.4, 11.2)} rise={p(t, 8.4, 9.2)} />
        {/* 11-16: Phone -> ??? -> Receiver */}
        <Arrow x1={ax + half + 20} y1={480} x2={790} y2={480} prog={p(t, 11.6, 12.6)} o={mid} />
        <Arrow x1={1130} y1={480} x2={bx - half - 20} y2={480} prog={p(t, 12.4, 13.4)} o={mid} />
        <Pos x={960} y={480} s={1 + 0.03 * Math.sin(t * 4)} o={mid}>
          <div style={{fontSize: 150, fontWeight: 800, color: C.bad}}>???</div>
        </Pos>
        {/* 16-22: ??? -> Bank network */}
        <Bank x={700} y={470} s={0.8} o={ch} label="Bank" />
        <Bank x={1180} y={470} s={0.8} o={ch} label="Bank" />
        <Arrow x1={350} y1={480} x2={600} y2={480} prog={p(t, 17, 18)} o={chArrow} />
        <Arrow x1={795} y1={480} x2={1085} y2={480} prog={p(t, 18, 19)} o={chArrow} />
        <Arrow x1={1275} y1={480} x2={1570} y2={480} prog={p(t, 19, 20)} o={chArrow} />
        <Title text="Phone" x={260} y={680} size={34} color={C.dim} o={ch} />
        <Title text="Receiver" x={1660} y={680} size={34} color={C.dim} o={ch} />
        {/* 22-28: packet chal raha hai + caption */}
        <Pos x={lerp(260, 1660, p(t, 22.5, 26.5))} y={480} o={win(t, 22.4, 26.8, 0.2)}>
          <div style={{width: 40, height: 40, borderRadius: 20, background: C.note, boxShadow: `0 0 30px 8px ${C.note2}`}} />
        </Pos>
        <Caption text="UPI के पीछे पूरा payment system काम करता है।" o={p(t, 22, 23)} />
      </>);
    }}</Scene>
  );
};
