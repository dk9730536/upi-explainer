import React from 'react';
import {Scene} from '../components/Scene';
import {Phone} from '../components/Phone';
import {Bank} from '../components/Bank';
import {Network} from '../components/Network';
import {Money} from '../components/Money';
import {Arrow} from '../components/Arrow';
import {Loading} from '../components/Loading';
import {Title} from '../components/Text';
import {Pos} from '../components/Pos';
import {SCENES} from '../timings';
import {C} from '../theme';
import {cl, lerp, p, win} from '../anim';

export const Scene6Pending: React.FC = () => {
  const {start: a, end: b} = SCENES.s6;
  return (
    <Scene a={a} b={b}>{(t) => {
      const g1 = win(t, 190, 197.4, 0.5);
      const chain = p(t, 197, 198);
      const u = t < 219 ? 0.92 * p(t, 197.5, 205) : lerp(0.92, 1, p(t, 220, 222));
      const px = lerp(300, 1585, u);
      const a3 = cl((px - 1325) / 260);
      const waiting = t >= 205 && t < 221;
      const a3Color = waiting ? C.warn : C.note;
      return (<>
        {/* 190-197: Processing */}
        <Money x={960} y={330} o={g1} />
        <Arrow x1={960} y1={430} x2={960} y2={590} prog={p(t, 191, 193)} o={g1} />
        <Title text="Processing…" y={690} size={72} o={g1} />
        <Loading x={960} y={820} size={80} o={g1} />
        {/* 197-226: Phone -> Bank -> Payment Network -> Receiver Bank */}
        <Phone x={240} y={480} s={0.5} o={chain}>
          <div style={{fontSize: 60, fontWeight: 800}}>₹100</div>
        </Phone>
        <Bank x={700} y={470} s={0.8} label="Bank" o={chain} />
        <Network x={1200} y={470} s={0.7} label="Payment Network" o={chain} />
        <Bank x={1680} y={470} s={0.8} label="Receiver Bank" o={chain} />
        <Arrow x1={330} y1={480} x2={600} y2={480} prog={p(t, 197.5, 198.5)} o={chain} />
        <Arrow x1={790} y1={480} x2={1075} y2={480} prog={p(t, 198.2, 199.2)} o={chain} />
        <Arrow x1={1325} y1={480} x2={1585} y2={480} prog={a3} o={chain} color={a3Color} />
        <Pos x={px} y={480} o={win(t, 197.6, 222.4, 0.3)}>
          <div style={{width: 40, height: 40, borderRadius: 20, background: a3Color, boxShadow: `0 0 30px 8px ${C.note2}`}} />
        </Pos>
        {/* 205-220: intezaar + Pending */}
        <Title text="Waiting for response…" y={830} size={70} color={C.warn} o={win(t, 205, 213, 0.4)} />
        <Title text="Payment Pending" y={830} size={84} color={C.warn} o={win(t, 213, 220.4, 0.4)} />
        <Loading x={960} y={690} size={90} color={C.warn} o={win(t, 205, 220.6, 0.4)} />
        {/* 220-226: response aaya */}
        <Title text="Status Updated" y={830} size={80} o={p(t, 222, 223)} rise={p(t, 222, 223)} />
      </>);
    }}</Scene>
  );
};
