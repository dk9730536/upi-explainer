import React from 'react';
import {Scene} from '../components/Scene';
import {Phone} from '../components/Phone';
import {Money} from '../components/Money';
import {Arrow} from '../components/Arrow';
import {NoSign} from '../components/Warning';
import {Tick} from '../components/Tick';
import {Pill, Title} from '../components/Text';
import {SCENES} from '../timings';
import {C} from '../theme';
import {lerp, lin, p, win} from '../anim';

const rows = ['Your Phone', 'Payment Request', 'Sender Bank', 'Payment Network', 'Receiver Bank'];
const flow = [{t: 'Phone', x: 260, w: 260}, {t: 'Bank', x: 720, w: 260}, {t: 'Payment System', x: 1250, w: 440}, {t: 'Bank', x: 1710, w: 260}];
const flowArrows = [[400, 580], [860, 1020], [1480, 1570]];

export const Scene7Final: React.FC = () => {
  const {start: a, end: b} = SCENES.s7;
  return (
    <Scene a={a} b={b}>{(t) => {
      const g1 = Math.min(p(t, 226, 226.8), 1 - lin(t, 231.4, 232));
      const fy = lerp(480, 300, p(t, 244.6, 245.4));
      const fo = Math.min(p(t, 240.2, 241), 1);
      return (<>
        {/* 226-232: phone -> phone, phir ruk jata hai */}
        <Phone x={560} y={540} o={g1}><div style={{fontSize: 28, color: C.dim}}>You</div><div style={{fontSize: 60, fontWeight: 800}}>₹100</div></Phone>
        <Phone x={1360} y={540} o={g1}><div style={{fontSize: 28, color: C.dim}}>Friend</div><div style={{fontSize: 60, fontWeight: 800}}>₹0</div></Phone>
        <Money x={lerp(600, 900, p(t, 226.6, 229.6))} y={540} s={0.7} o={p(t, 226.4, 227) * g1 * (1 - 0.6 * p(t, 229.6, 230.2))} />
        <NoSign x={960} y={540} s={lerp(0.5, 1, p(t, 229.8, 230.4))} o={p(t, 229.8, 230.4) * g1} />
        {/* 232-240: vertical list */}
        {rows.map((r, i) => (
          <React.Fragment key={r}>
            <Pill text={r} x={960} y={105 + i * 170} w={520} h={90} o={p(t, 232.4 + i, 232.9 + i) * win(t, 232, 240.2, 0.4) * 1}
              fill={i === 1 ? C.note2 : C.card} />
            <Arrow x1={960} y1={155 + i * 170} x2={960} y2={225 + i * 170} width={8} prog={p(t, 232.9 + i, 233.5 + i)} o={win(t, 232, 240.2, 0.4)} />
          </React.Fragment>
        ))}
        <Money x={960} y={955} s={0.55} o={p(t, 237.4, 238) * win(t, 232, 240.2, 0.4)} />
        {/* 240-250: flow + Complete */}
        {flow.map((f, i) => <Pill key={i} text={f.t} x={f.x} y={fy} w={f.w} o={fo * p(t, 240.2 + i * 0.5, 240.8 + i * 0.5)} fill={i === 2 ? C.note2 : C.card} />)}
        {flowArrows.map(([x1, x2], i) => <Arrow key={i} x1={x1} y1={fy} x2={x2} y2={fy} width={8} prog={p(t, 240.8 + i * 0.5, 241.4 + i * 0.5)} o={fo} />)}
        <Tick x={960} y={640} s={1.5} o={p(t, 245.2, 245.6)} prog={p(t, 245.4, 246.4)} />
        <Title text="Payment Complete" y={850} size={80} color={C.ok} o={p(t, 245.6, 246.4)} rise={p(t, 245.6, 246.4)} />
      </>);
    }}</Scene>
  );
};
