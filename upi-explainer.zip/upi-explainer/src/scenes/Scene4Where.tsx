import React from 'react';
import {Scene} from '../components/Scene';
import {Bank} from '../components/Bank';
import {Network} from '../components/Network';
import {Money} from '../components/Money';
import {Arrow} from '../components/Arrow';
import {Tick} from '../components/Tick';
import {Caption, Pill, Title} from '../components/Text';
import {Pos} from '../components/Pos';
import {SCENES} from '../timings';
import {C, FONT} from '../theme';
import {lerp, p, win} from '../anim';

const Account: React.FC<{x: number; y: number; title: string; value: number; badge: string; badgeColor: string; badgeO: number; o: number}> =
  ({x, y, title, value, badge, badgeColor, badgeO, o}) => (
    <Pos x={x} y={y} o={o}>
      <div style={{width: 560, padding: '36px 44px', borderRadius: 32, background: C.card, border: `3px solid ${C.line}`, fontFamily: FONT}}>
        <div style={{fontSize: 34, color: C.dim}}>{title}</div>
        <div style={{fontSize: 110, fontWeight: 800}}>₹{value}</div>
        <div style={{display: 'inline-block', marginTop: 10, padding: '8px 26px', borderRadius: 30, fontSize: 38, fontWeight: 800,
          background: badgeColor, color: '#12173a', opacity: badgeO}}>{badge}</div>
      </div>
    </Pos>
  );

export const Scene4Where: React.FC = () => {
  const {start: a, end: b} = SCENES.s4;
  return (
    <Scene a={a} b={b}>{(t) => {
      const k4 = p(t, 129.5, 130.5);
      const cloudO = Math.min(p(t, 108, 109), 1 - p(t, 139.4, 140.2));
      const chain = p(t, 130, 131) * (1 - p(t, 139.4, 140.2));
      const moneyO = Math.min(p(t, 108.4, 109), 1 - p(t, 119, 119.8));
      const rq = p(t, 133, 139);
      return (<>
        {/* 108-120: UPI cloud, paisa andar nahi jata */}
        <Network x={960} y={lerp(470, 520, k4)} s={lerp(1.6, 0.7, k4)} inner="UPI" routing={p(t, 120, 123)} o={cloudO}
          label={t >= 129.5 ? 'UPI Payment Network' : undefined} />
        <Money x={lerp(200, 520, p(t, 108.5, 115))} y={470} s={0.6} o={moneyO} />
        <div style={{position: 'absolute', left: 640, top: 360, width: 10, height: 220, borderRadius: 5, background: C.bad, opacity: p(t, 115, 115.6) * moneyO}} />
        <Caption text="UPI कोई wallet नहीं है।" o={win(t, 115, 120.4, 0.5)} />
        <Title text="Payment Request / Routing" y={830} size={60} o={win(t, 122, 129.6, 0.5)} rise={p(t, 122, 123)} />
        {/* 130-140: Sender Bank -> UPI Payment Network -> Receiver Bank (paisa network mein nahi) */}
        <Bank x={960} y={190} s={0.6} label="Sender Bank" o={chain} />
        <Bank x={960} y={860} s={0.6} label="Receiver Bank" o={chain} />
        <Arrow x1={960} y1={285} x2={960} y2={405} prog={p(t, 131, 132.5)} o={chain} />
        <Arrow x1={960} y1={625} x2={960} y2={770} prog={p(t, 132.5, 134)} o={chain} />
        <Pos x={960} y={lerp(285, 775, rq)} o={chain * win(t, 133, 139, 0.3)}>
          <div style={{width: 30, height: 30, borderRadius: 15, background: C.note, boxShadow: `0 0 24px 6px ${C.note2}`}} />
        </Pos>
        {/* 140-156: bank accounts */}
        <Account x={560} y={520} title="Sender Bank Account" value={Math.round(lerp(500, 400, p(t, 141, 145)))}
          badge="₹100 Debit" badgeColor={C.bad} badgeO={p(t, 144, 145)} o={p(t, 140.4, 141.2)} />
        <Account x={1360} y={520} title="Receiver Bank Account" value={Math.round(lerp(0, 100, p(t, 149, 153)))}
          badge="₹100 Credit" badgeColor={C.ok} badgeO={p(t, 152, 153)} o={p(t, 148, 148.8)} />
        {/* 156-162 */}
        <Tick x={960} y={520} s={1.2} o={p(t, 156, 156.5)} prog={p(t, 156, 157.2)} />
        <Title text="Payment Successful" y={860} size={76} color={C.ok} o={p(t, 156.4, 157.2)} rise={p(t, 156.4, 157.2)} />
      </>);
    }}</Scene>
  );
};
