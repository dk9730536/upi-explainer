import React from 'react';
import {Scene} from '../components/Scene';
import {Pos} from '../components/Pos';
import {Title} from '../components/Text';
import {SCENES} from '../timings';
import {C, FONT} from '../theme';
import {lerp, p, win} from '../anim';

// NOTE: ye sirf placeholder logo hai. Apna asli logo yahan lagana ho to <svg> badal do.
export const Scene8Ending: React.FC = () => {
  const {start: a, end: b} = SCENES.s8;
  return (
    <Scene a={a} b={b}>{(t) => {
      const up = p(t, 256, 257);
      const press = 1 - 0.08 * win(t, 258, 258.6, 0.25);
      return (<>
        <Pos x={960} y={lerp(380, 250, up)} s={lerp(0.5, 1.2, p(t, 250.4, 251.4))} o={p(t, 250.4, 251)}>
          <svg width={200} height={200} viewBox="0 0 200 200">
            <circle cx={100} cy={100} r={90} fill={C.mint} />
            <path d="M138 66 A48 48 0 1 0 138 134" fill="none" stroke={C.bg} strokeWidth={22} strokeLinecap="round" />
          </svg>
        </Pos>
        <Title text="CurioMint World" y={lerp(620, 470, up)} size={124} o={p(t, 251, 252)} rise={p(t, 251, 252)} />
        <Pos x={960} y={700} s={lerp(0.5, 1, p(t, 256.6, 257.4)) * press} o={p(t, 256.6, 257.4)}>
          <div style={{width: 520, height: 130, borderRadius: 32, background: '#ff2d2d', color: '#fff', fontFamily: FONT, fontSize: 66,
            fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 12px 40px rgba(255,45,45,.4)'}}>Subscribe</div>
        </Pos>
        <Title text="Subscribe for more!" y={890} size={64} o={p(t, 257.4, 258.2)} rise={p(t, 257.4, 258.2)} />
      </>);
    }}</Scene>
  );
};
