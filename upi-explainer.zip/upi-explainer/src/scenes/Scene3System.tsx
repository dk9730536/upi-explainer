import React from 'react';
import {Scene} from '../components/Scene';
import {Phone} from '../components/Phone';
import {Bank} from '../components/Bank';
import {Network} from '../components/Network';
import {Arrow} from '../components/Arrow';
import {Tick} from '../components/Tick';
import {Loading} from '../components/Loading';
import {Pill, Title} from '../components/Text';
import {Pos} from '../components/Pos';
import {SCENES} from '../timings';
import {C} from '../theme';
import {lerp, lin, p, win} from '../anim';

export const Scene3System: React.FC = () => {
  const {start: a, end: b} = SCENES.s3;
  return (
    <Scene a={a} b={b}>{(t) => {
      const dimA = 1 - p(t, 83.6, 84.4);           // phone/network/arrows dhundhle hote hain jab bank zoom hota hai
      const zk = p(t, 83.6, 84.8);
      const bankO = p(t, 75.6, 76.4) * (1 - lin(t, 91.4, 92));
      const B = p(t, 92, 92.8);
      const pktX = t < 76 ? lerp(300, 800, p(t, 63, 76)) : lerp(800, 1400, p(t, 76, 84));
      const dots = '.'.repeat(1 + (Math.floor(t * 2) % 3));
      return (<>
        {/* 60-84: Phone -> UPI Network -> Sender Bank */}
        <Phone x={250} y={480} s={0.6} o={p(t, 60, 61) * dimA}>
          <div style={{fontSize: 26, color: C.dim}}>UPI App</div><div style={{fontSize: 64, fontWeight: 800}}>₹100</div>
        </Phone>
        <Title text="UPI App" x={250} y={690} size={38} o={p(t, 60.5, 61.5) * dimA} />
        <Network x={800} y={480} label="UPI Network" o={p(t, 67, 68) * dimA} />
        <Arrow x1={350} y1={480} x2={630} y2={480} prog={p(t, 67, 70)} o={dimA} />
        <Bank x={lerp(1400, 960, zk)} y={lerp(480, 400, zk)} s={lerp(0.9, 1.5, zk)} o={bankO} label="Sender Bank" />
        <Arrow x1={975} y1={480} x2={1300} y2={480} prog={p(t, 76, 79)} o={dimA} />
        <Pill text="Payment Request" x={pktX} y={340} w={300} h={64} size={30} fill={C.note2} o={p(t, 63, 63.6) * dimA} />
        {/* 84-92: bank ke andar */}
        <Pill text="Balance Check" x={960} y={690} w={560} h={84} o={p(t, 84.6, 85.4)} />
        <Pill text="Sufficient balance" x={990} y={790} w={500} h={84} color={C.ok} o={p(t, 87, 87.8)} />
        <Tick x={640} y={790} s={0.4} o={p(t, 87, 87.8)} prog={p(t, 87, 88)} />
        <Pill text="Transaction Authorized" x={960} y={890} w={640} h={84} fill={C.note2} o={p(t, 89.5, 90.3)} />
        {/* 92-108: Sender Bank -> Payment System -> Receiver Bank */}
        <Bank x={460} y={470} s={0.9} o={B} label="Sender Bank" />
        <Network x={960} y={470} inner="UPI" label="Payment System" o={B} />
        <Bank x={1460} y={470} s={0.9} o={B} label="Receiver Bank" />
        <Arrow x1={565} y1={470} x2={790} y2={470} prog={p(t, 92.6, 95)} o={B} />
        <Arrow x1={1135} y1={470} x2={1355} y2={470} prog={p(t, 95, 97.5)} o={B} />
        <Pos x={lerp(460, 1460, p(t, 96, 101))} y={470} o={win(t, 96, 101.2, 0.2)}>
          <div style={{width: 36, height: 36, borderRadius: 18, background: C.note, boxShadow: `0 0 30px 8px ${C.note2}`}} />
        </Pos>
        <Title text={`Transaction Processing${dots}`} y={830} size={64} o={p(t, 102, 102.8)} />
        <Loading x={960} y={710} size={80} o={p(t, 102, 102.8)} />
      </>);
    }}</Scene>
  );
};
