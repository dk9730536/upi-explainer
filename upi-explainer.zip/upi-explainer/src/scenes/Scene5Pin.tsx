import React from 'react';
import {Scene} from '../components/Scene';
import {Phone} from '../components/Phone';
import {Bank} from '../components/Bank';
import {Lock} from '../components/Lock';
import {Warning} from '../components/Warning';
import {Arrow} from '../components/Arrow';
import {Tick} from '../components/Tick';
import {Pill, Title} from '../components/Text';
import {Pos} from '../components/Pos';
import {SCENES} from '../timings';
import {C} from '../theme';
import {lerp, lin, p, win} from '../anim';

export const Scene5Pin: React.FC = () => {
  const {start: a, end: b} = SCENES.s5;
  return (
    <Scene a={a} b={b}>{(t) => {
      const G1 = p(t, 162, 163) * (1 - lin(t, 174.8, 175.4));
      const G2 = p(t, 175.4, 176.2) * (1 - lin(t, 181.4, 182));
      const G3 = p(t, 182, 182.8);
      const px = lerp(960, 520, p(t, 167.6, 168.6));
      return (<>
        {/* 162-175: PIN -> Authorization */}
        <Phone x={px} y={500} s={0.9} o={G1}>
          <div style={{fontSize: 28, color: C.dim, marginBottom: 16}}>Enter UPI PIN</div>
          <div style={{display: 'flex', gap: 22}}>{[0, 1, 2, 3].map((i) => <div key={i} style={{width: 36, height: 36, borderRadius: 18, background: C.note}} />)}</div>
        </Phone>
        <Lock x={960} y={500} s={1.5} o={p(t, 168, 169) * G1} open={p(t, 171, 172)} />
        <Bank x={1400} y={500} s={0.9} o={p(t, 172, 173) * G1} label="Your Bank" />
        <Arrow x1={680} y1={500} x2={860} y2={500} prog={p(t, 168, 170)} o={G1} />
        <Arrow x1={1065} y1={500} x2={1290} y2={500} prog={p(t, 172, 174)} o={G1} />
        <Title text="PIN" x={770} y={400} size={40} color={C.dim} o={p(t, 168.5, 169.5) * G1} />
        <Title text="Authorization" x={1180} y={400} size={40} color={C.dim} o={p(t, 172.5, 173.5) * G1} />
        <Tick x={1400} y={330} s={0.6} o={p(t, 173.4, 173.8) * G1} prog={p(t, 173.5, 174.5)} />
        {/* 175-182: PIN lock ke peeche */}
        <Pos x={960} y={420} o={G2}>
          <div style={{display: 'flex', gap: 22}}>{[0, 1, 2, 3].map((i) => <div key={i} style={{width: 46, height: 46, borderRadius: 23, background: C.note}} />)}</div>
        </Pos>
        <Lock x={960} y={420} s={lerp(3, 2.2, p(t, 177, 177.8))} o={p(t, 177, 177.6) * G2} />
        <Title text="UPI PIN = Payment Authorization" y={760} size={64} o={G2} rise={p(t, 175.6, 176.4)} />
        {/* 182-190: warning */}
        <Warning x={960} y={270} s={1.3 + 0.04 * Math.sin(t * 5)} o={G3} />
        <Title text="UPI PIN कभी share न करें" y={510} size={80} color={C.warn} o={G3} rise={p(t, 182.4, 183.2)} />
        <Pill text="Bank employee?" x={560} y={760} w={460} o={p(t, 186, 186.8)} />
        <Arrow x1={800} y1={760} x2={1070} y2={760} prog={p(t, 186.6, 187.6)} o={p(t, 186.6, 187) * G3} />
        <Pill text="PIN share नहीं करना है" x={1360} y={760} w={560} color={C.warn} o={p(t, 187.4, 188.2)} />
      </>);
    }}</Scene>
  );
};
