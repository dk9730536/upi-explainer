import React from 'react';
import {Scene} from '../components/Scene';
import {Phone} from '../components/Phone';
import {QRCode} from '../components/QRCode';
import {Lock} from '../components/Lock';
import {Money} from '../components/Money';
import {NoSign} from '../components/Warning';
import {Tick} from '../components/Tick';
import {Caption} from '../components/Text';
import {SCENES} from '../timings';
import {C} from '../theme';
import {lerp, p, win} from '../anim';

const sm: React.CSSProperties = {fontSize: 28, color: C.dim, marginBottom: 16};
const big: React.CSSProperties = {fontSize: 70, fontWeight: 800};

export const Scene2Start: React.FC = () => {
  const {start: a, end: b} = SCENES.s2;
  return (
    <Scene a={a} b={b}>{(t) => {
      const k = p(t, 41.5, 42.5);
      const px = lerp(lerp(lerp(960, 620, p(t, 34.5, 35.5)), 960, k), 520, p(t, 53.6, 54.6));
      const amt = t < 43.4 ? '₹' : t < 44.2 ? '₹1' : t < 45 ? '₹10' : '₹100';
      const cursor = Math.floor(t * 2) % 2 === 0 && t < 47 ? '|' : '';
      const dots = [49, 50, 51, 52].map((s) => t > s);
      let screen: React.ReactNode;
      if (t < 35) screen = (<><div style={sm}>UPI App</div>
        <div style={{background: C.note2, borderRadius: 30, padding: '18px 34px', fontSize: 34, fontWeight: 800,
          transform: `scale(${1 + 0.05 * Math.sin(t * 5)})`}}>{'Scan & Pay'}</div></>);
      else if (t < 42) screen = (<><div style={sm}>Scan QR</div>
        <div style={{width: 190, height: 190, border: `5px dashed ${C.note}`, borderRadius: 20}} /></>);
      else if (t < 48) screen = (<><div style={sm}>Amount</div><div style={big}>{amt}{cursor}</div></>);
      else if (t < 54) screen = (<><div style={sm}>Enter UPI PIN</div>
        <div style={{display: 'flex', gap: 22}}>{dots.map((d, i) => <div key={i} style={{width: 36, height: 36, borderRadius: 18,
          background: d ? C.note : 'transparent', border: `4px solid ${C.note}`}} />)}</div></>);
      else screen = (<><div style={sm}>Sent</div><div style={big}>₹100</div></>);
      const scan = t > 35.4 && t < 41.4 ? ((t - 35.4) / 2) % 1 : -1;
      return (<>
        <Phone x={px} y={540} s={lerp(0.85, 1, p(t, 28, 29.2))} o={p(t, 28, 29.2)}>{screen}</Phone>
        {/* 35-42: QR + scan line */}
        <QRCode x={1300} y={540} s={1} o={win(t, 34.6, 42.4)} scan={scan} />
        <Tick x={1300} y={540} s={1.1} o={win(t, 41, 42.5, 0.3)} prog={p(t, 41, 41.8)} />
        {/* 48-54: lock */}
        <Lock x={1400} y={540} s={1.5} o={win(t, 48, 54.4, 0.5)} open={1 - p(t, 52.3, 52.9)} />
        {/* 54-60: phone se phone -> NO */}
        <Phone x={1400} y={540} o={p(t, 53.8, 54.6)}>
          <div style={sm}>Receiver</div><div style={big}>₹0</div>
        </Phone>
        <Money x={lerp(580, 800, p(t, 54.8, 57))} y={540} s={0.7} o={p(t, 54.6, 55) * (1 - 0.6 * p(t, 57, 57.6))} />
        <NoSign x={960} y={540} s={lerp(0.5, 1, p(t, 57, 57.6))} o={p(t, 57, 57.6)} />
        <Caption text="पैसा सीधे फोन से फोन में नहीं जाता।" o={p(t, 57.6, 58.6)} />
      </>);
    }}</Scene>
  );
};
