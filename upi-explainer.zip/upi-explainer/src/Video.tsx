import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {C, FONT} from './theme';
import {FPS, SCENES} from './timings';
import {Scene1Hook} from './scenes/Scene1Hook';
import {Scene2Start} from './scenes/Scene2Start';
import {Scene3System} from './scenes/Scene3System';
import {Scene4Where} from './scenes/Scene4Where';
import {Scene5Pin} from './scenes/Scene5Pin';
import {Scene6Pending} from './scenes/Scene6Pending';
import {Scene7Final} from './scenes/Scene7Final';
import {Scene8Ending} from './scenes/Scene8Ending';

const list = [
  [SCENES.s1, Scene1Hook], [SCENES.s2, Scene2Start], [SCENES.s3, Scene3System], [SCENES.s4, Scene4Where],
  [SCENES.s5, Scene5Pin], [SCENES.s6, Scene6Pending], [SCENES.s7, Scene7Final], [SCENES.s8, Scene8Ending],
] as const;

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: `radial-gradient(110% 80% at 50% 25%, ${C.bg2}, ${C.bg} 75%)`, fontFamily: FONT, color: C.fg}}>
    {list.map(([s, Comp], i) => (
      <Sequence key={i} from={Math.round(s.start * FPS)} durationInFrames={Math.round((s.end - s.start) * FPS)}>
        <Comp />
      </Sequence>
    ))}
  </AbsoluteFill>
);
