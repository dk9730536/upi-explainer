# UPI Explainer (Remotion)

## Setup (ek baar)
1. Node.js (v18+) install karo: https://nodejs.org  (LTS version)
2. Is folder mein terminal kholo, phir:  `npm install`

## Preview
`npm start`   -> browser mein Remotion Studio khulega, wahan play/scrub kar sakte ho.

## MP4 render (1920x1080, 30 FPS)
`npm run build`   -> file banegi: out/upi-explainer.mp4

## Edit kaise karein
- Scene ka timing:      src/timings.ts
- Text / visuals:       src/scenes/SceneX....tsx  (har scene alag file)
- Reusable pieces:      src/components/ (Phone, Bank, Network, Arrow, Money, QRCode, Lock, Warning, Loading, Text)
- Scene ke andar sab timings "absolute seconds" mein hain (0:28 = 28, 1:32 = 92).
